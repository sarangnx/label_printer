cordova.define("tsc-cordova-sample.service", function(require, exports, module) {
// methods
exports.show = function (message) {
    cordova.exec(null, null, "service", "show", [message]);
};
});
