cordova.define('cordova/plugin_list', function(require, exports, module) {
module.exports = [
    {
        "id": "cordova-plugin-bluetoothle.BluetoothLe",
        "file": "plugins/cordova-plugin-bluetoothle/www/bluetoothle.js",
        "pluginId": "cordova-plugin-bluetoothle",
        "clobbers": [
            "window.bluetoothle"
        ]
    },
    {
        "id": "tsc-cordova-sample.service",
        "file": "plugins/tsc-cordova-sample/www/tsc.cordova.sample.service.js",
        "pluginId": "tsc-cordova-sample",
        "clobbers": [
            "tsc.cordova.sample.service"
        ]
    }
];
module.exports.metadata = 
// TOP OF METADATA
{
    "cordova-plugin-whitelist": "1.2.2",
    "cordova-plugin-bluetoothle": "4.4.3",
    "tsc-cordova-sample": "1.0.0"
};
// BOTTOM OF METADATA
});