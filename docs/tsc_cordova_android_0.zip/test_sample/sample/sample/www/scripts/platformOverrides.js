﻿/*
	此檔案已由 /merges 資料夾中平台專用的程式碼所取代。
	如需詳細資訊，請參閱 http://taco.visualstudio.com/zh-tw/docs/configure-app/#Content。
*/